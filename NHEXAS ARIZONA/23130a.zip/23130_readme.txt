
Data Set Metadata



Entry ID:

23130



Complete Data Set contains 238 columns, 432 rows, and 1 segment(s).



Name:

NHEXAS PHASE I ARIZONA STUDY--METALS-XRF IN AIR ANALYTICAL RESULTS


Abstract:

The Metals-XRF in Air data set contains X-ray fluorescence (XRF) analytical
results for measurements of up to 27 metals in 432 air samples over 236
households.  Samples were taken by pumping standardized air volumes through
filters at indoor and outdoor sites around each household being sampled.
Analysis occurred at the Arizona Laboratory using a Spectrace 9000 portable XRF.
The primary metals of interest include lead (CAS# 7439-92-1), arsenic (CAS#
7440-38-2), cadmium (CAS# 7440-43-9), nickel (CAS# 7440-02-0), chromium (CAS#
7440-47-3), barium (CAS# 7440-39-3), manganese (CAS# 7439-96-5), selenium (CAS#
7782-49-2), vanadium (CAS# 7440-62-2), copper (CAS# 7440-50-8), and zinc (CAS#
7440-66-6).  Keywords: air; metals; XRF.
 
The National Human Exposure Assessment Survey (NHEXAS) is a federal
interagency research effort coordinated by the Environmental Protection Agency
(EPA), Office of Research and Development (ORD).  Phase I consists of
demonstration/scoping studies using probability-based sampling designs.  The
studies collected household environmental and personal samples for chemical
analysis, and questionnaires were administered.  The NHEXAS Phase I
Questionnaires were organized into six modules for simplicity in administration
(to minimize respondent burden and maximize participation rates at each step)
and for collecting information that can be temporally related to the exposure,
concentration, and/or biological measurements collected in NHEXAS:  Descriptive,
Baseline, Technician, Follow-up, Time and activity diary, and Dietary diary (and
follow-up).  The NHEXAS Arizona study sampled residences determined by a
population-based probability research design for the total population of Arizona
and measured metals, pesticides, and volatile organic compounds (VOCs).
Analytical results were obtained under strict QA/QC requirements during
collection, processing, and final deposition into databases.  In addition,
strict standard operating procedures were followed throughout the NHEXAS Arizona
study.  The study was conducted by a consortium composed of the University of
Arizona, Battelle Columbus, and the Illinois Institute of Technology.  Data
collection occurred between June 1995 and February 1998 for the participating
households.<br>


Data Use and Constraints:

NHEXAS is a rich source of data that EPA encourages you to use for research and
analysis. Users must be familiar with data file manipulation and analysis.  EPA
cannot analyze, check results, debug programs, or review literature for your
work. Thoroughly reviewing the documentation on the survey's planning, analytic
guidelines, and datasets available through HEDS and EIMS should resolve most
questions. If you have questions after reviewing the documentation, please
contact the Human Exposure and Atmospheric Sciences Division at 919-541-3184 or
email "admin.heds@epa.gov". Please review the data use restrictions in the
Notice field and your agreement to comply with these restrictions in using the
data.
 
These data are the result of a probability-based sampling design specific to
the population under study. Thus the data may or may not be representative of
subsets of this study's population or of other populations. The study was
designed to test certain hypotheses, which may limit its applicability for other
purposes. When using these data it is important to consider the percentage of
non-responses or non-detects in the data as an indicator of its usefulness for
other purposes. The U.S. EPA accepts no liability for any errors or omissions in
the results included in the data sets, associated information, and/or
documentation.
 
Based on the output format selected by the user and the software into which
the data set is imported, users may notice measurements and sampling weights are
zero-padded to the right of non-zero decimal digits. These zeroes are a function
of the formatting process and the software's acceptance of that format and
should not be construed as significant digits in the value. Measurement values
are provided with four significant digits; sampling weights are provided with
three decimal digits.
 
Some code values may have been revised from the values on the original
questionnaire forms.  Check the appropriate code set supplied with the data.


Notice:

WARNING! DATA USE RESTRICTIONS
 
Read Carefully Before Using
 
The EPA does all it can to ensure that the
identity of survey participants cannot be disclosed.  All direct identifiers, as
well as any characteristics that might lead to identifications, are omitted from
the data.  Any intentional identification or disclosure of a person or
establishment violates the assurances of confidentiality given to the providers
of the information.  Therefore, users will (1) use the data in this study for
statistical reporting and analysis only; (2) make no use of the identity of any
person or establishment discovered inadvertently and will advise the HEDS
Administrator of any such discovery; (3) will not link this data with
individually identifiable data from other EPA or non-EPA data.
 
By using the data you signify your agreement to comply with the above-stated
statutorily based requirements.


Additional Information:

To access the data set, select the Downloads link on the navigation bar to the
left.  Then select the download entry "Download Data Set."
 
Please review the "Data Use & Constraints" information by selecting the
Quality Assurance link to the left.


Version:

1.0


Version Description:

(Not currently available.)





For more information on the structure of the files included in this package,
please see the document "HEDS How To Use--Reference", accessible from the
HEDS Home Page.

