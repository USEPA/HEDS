
Data Set Metadata



Entry ID:

22900



Complete Data Set contains 56 columns, 458 rows, and 1 segment(s).



Name:

NHEXAS PHASE I MARYLAND STUDY--METALS IN AIR ANALYTICAL RESULTS


Abstract:

The Metals in Air data set contains analytical results for measurements of up to
4 metals in 458 air samples over 79 households.  Twenty-four-hour samples were
taken over a one-week period using a continuous pump and solenoid apparatus by
pumping a standardized air volume through Teflon (R) filters at indoor and
outdoor sites around each household being sampled.  The primary metals of
interest included arsenic (CAS# 7440-38-2), cadmium (CAS# 7440-43-9), chromium
(CAS# 7440-47-3), and lead (CAS# 7439-92-1).  Keywords: air; metals.
 
The National Human Exposure Assessment Survey (NHEXAS) is a federal
interagency research effort coordinated by the Environmental Protection Agency
(EPA), Office of Research and Development (ORD).  Phase I consists of
demonstration/scoping studies using probability-based sampling designs.  The
studies collected household environmental and personal samples for chemical
analysis, and questionnaires were administered.  The NHEXAS Phase I
Questionnaires were organized into six modules for simplicity in administration
(to minimize respondent burden and maximize participation rates at each step)
and for collecting information that can be temporally related to the exposure,
concentration, and/or biological measurements collected in NHEXAS:  Descriptive,
Baseline, Technician, Follow-up, Time and activity diary, and Dietary diary (and
follow-up).  The NHEXAS-Maryland study sampled residences determined by a
proportion-based sample of Baltimore and four adjacent counties and measured
metals, pesticides, and PAHs. The study was conducted by Harvard University,
Emory University, Johns Hopkins University, and Westat. Data collection occurred
up to six times over one year for the participating households.  Analytical
results were obtained under strict QA/QC requirements during collection,
processing, and final deposition into databases.


Data Use and Constraints:

NHEXAS is a rich source of data that EPA encourages you to use for research and
analysis. Users must be familiar with data file manipulation and analysis.  EPA
cannot analyze, check results, debug programs, or review literature for your
work. Thoroughly reviewing the documentation on the survey's planning, analytic
guidelines, and datasets available through HEDS and EIMS should resolve most
questions. If you have questions after reviewing the documentation, please
contact the Human Exposure and Atmospheric Sciences Division at 919-541?3184 or
email "admin.heds@epa.gov". Please review the data use restrictions in the
Notice field and your agreement to comply with these restrictions in using the
data.
 
These data are the result of a probability-based sampling design specific to
the population under study. Thus the data may or may not be representative of
subsets of this study's population or of other populations. The study was
designed to test certain hypotheses, which may limit its applicability for other
purposes. When using these data it is important to consider the percentage of
non-responses or non-detects in the data as an indicator of its usefulness for
other purposes. The U.S. EPA accepts no liability for any errors or omissions in
the results included in the data sets, associated information, and/or
documentation.
 
Based on the output format selected by the user and the software into which
the data set is imported, users may notice measurements and sampling weights are
zero-padded to the right of non-zero decimal digits. These zeroes are a function
of the formatting process and the software's acceptance of that format and
should not be construed as significant digits in the value. Measurement values
are provided with four significant digits; sampling weights are provided with
three decimal digits.
 
Information records for samples or questionnaires not meeting chain of custody
or quality assurance requirements have not been included in this data set.


Notice:

WARNING! DATA USE RESTRICTIONS
 
Read Carefully Before Using
 
The EPA does all it can to ensure that the
identity of survey participants cannot be disclosed.  All direct identifiers, as
well as any characteristics that might lead to identifications, are omitted from
the data.  Any intentional identification or disclosure of a person or
establishment violates the assurances of confidentiality given to the providers
of the information.  Therefore, users will (1) use the data in this study for
statistical reporting and analysis only; (2) make no use of the identity of any
person or establishment discovered inadvertently and will advise the HEDS
Administrator of any such discovery; (3) will not link this data with
individually identifiable data from other EPA or non-EPA data.
 
By using the data you signify your agreement to comply with the above-stated
statutorily based requirements.


Additional Information:

To access the data set, select the Downloads link on the navigation bar to the
left.  Then select the download entry "Download Data Set."


Version:

1.0


Version Description:

(Not currently available.)





For more information on the structure of the files included in this package,
please see the document "HEDS How To Use--Reference", accessible from the
HEDS Home Page.

