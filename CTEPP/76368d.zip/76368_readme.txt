Data Set Metadata  

Entry ID:

76368

Complete Data Set contains 26 columns, 67 rows, and 1 segment(s).


Name:

CTEPP NC DATA COLLECTED ON FORM 01_RDD: RECRUITMENT SURVEY FOR HOME SAMPLE 
SUBJECTS


Abstract:

This data set contains data concerning the the eligiblity of preschool children 
who stayed home during the day with their primary adult caregiver and were 
recruited into the study.

The Children's Total Exposure to Persistent Pesticides and Other Persistent 
Pollutant (CTEPP) study was one of the largest aggregate exposure studies of 
young children in the United States. The CTEPP study examined the exposures 
of about 260 preschool children and their primary adult caregivers to pollutants 
commonly found in their everyday environments. The major objectives of this 
three-year study were to quantify children's aggregate exposures, to apportion 
the exposure pathways, to identify the important exposure media, and to identify 
the important hypotheses for future testing. Participants were recruited from 
randomly selected day care centers and homes in six North Carolina and six Ohio 
counties. Monitoring was performed over 48-hr periods at the children's homes 
and/or day care centers. Multimedia samples that were collected included 
duplicate diet, drinking water, indoor air, outdoor air, urine, floor dust, 
play area soil, transferable residues, and surface wipes (hand, food 
preparation, and hard floor). The samples were extracted and analyzed by gas 
chromatography/mass spectrometry for over 50 pollutants including pesticides, 
phthalate esters, phenols, polychlorinated biphenyls, and polycyclic aromatic 
hydrocarbons. In addition, 20% of the preschool children were videotaped for 
about two hours at homes in Ohio to supplement the activity diaries and 
observations. All of the measurement data and other supplemental information 
were incorporated into the CTEPP database. The data were statistically analyzed 
to quantify the concentrations of the pollutants in multimedia and to estimate 
the preschool children's exposures through the inhalation, ingestion, and dermal 
routes. This database is considered one of the largest resources for 
characterizing young children's exposures to pollutants in their everyday 
environments.


Data Use and Constraints:

CTEPP is a rich source of data that EPA encourages you to use for research and 
analysis. Users must be familiar with data file manipulation and analysis.  EPA 
cannot analyze, check results, debug programs, or review literature for your 
work. Thoroughly reviewing the documentation on the survey's planning, analytic 
guidelines, and datasets available through HEDS and EIMS should resolve most 
questions. If you have questions after reviewing the documentation, please 
contact the Human Exposure and Atmospheric Sciences Division at 919-541-3184 or
email "admin.heds@epa.gov". Please review the data use restrictions in the 
Notice field and your agreement to comply with these restrictions in using the 
data.

The U.S. EPA accepts no liability for any errors or omissions in the results 
included in the data sets, associated information, and/or documentation.

Information records for samples or questionnaires not meeting chain of custody 
or quality assurance requirements have not been included in this data set.
 

Notice:

WARNING! DATA USE RESTRICTIONS  
 Read Carefully Before Using  
 
The EPA does all it can to ensure that the identity of survey participants 
cannot be disclosed.  All direct identifiers, as well as any characteristics 
that might lead to identifications, are omitted from the data.  Any intentional 
identification or disclosure of a person or establishment violates the 
assurances of confidentiality given to the providers of the information.  
Therefore, users will (1) use the data in this study for statistical reporting 
and analysis only; (2) make no use of the identity of any person or 
establishment discovered inadvertently and will advise the HEDS Administrator 
of any such discovery; (3) will not link this data with individually 
identifiable data from other EPA or non-EPA data.  

By using the data you signify your agreement to comply with the above-stated
statutorily based requirements.   


Accessing CTEPP-North Carolina Data:

The tables in the CTEPP data sets have a complicated relationship which makes 
retrieving data from them somewhat cumbersome. This document is designed to make 
that job a little easier.


Additional Resources:

In addition to this readme file, explanations of CTEPP data and structure of 
downloaded files can be found at the Human Exposure Database System web site 
(http://www.epa.gov/heds). For information on the CTEPP study, select "HEDS 
Studies" on the left side of the page and select the link to CTEPP. The 
"Study Information Page" will provide links to study specific metadata, data 
sets, and documents. For general information on the structure of HEDS click on 
"First Time Users" on the left side of the main HEDS page. For details on the 
structure of downloaded datasets, select "Reference" on the left side of the 
main HEDS page.


Download Files:

The downloadable files are provided in zip files containing all of the data 
relevant to a single table of data in the CTEPP study. If the table has more 
than 250 variables it may be split up into segments (explained on the Reference 
page mentioned above).  Each zip file will contain at least 7 files.

* This readme file.
* One or more dataset files (xxxxxdsy.txt).
* One or more codeset files (xxxxxcsy.txt).
* One or more dictionary files (xxxxxcsy.txt).
* The Index file (Index_nc.txt).
* The Index dictionary file (Index_ncdd.txt).
* The Index code set file (Index_nccs.txt).

Where xxxxx is a 5 digit number and y, if appropriate indicates which segment the 
file belongs to. When it is necessary to supply datasets in more than one segment, 
the codeset and dictionary files are supplied both for the individual segments and 
for the table as a whole. The downloaded dBase files will be named as the text 
files except that their extensions will be '.dbf'.

The segments can be joined using the primary key for that table (see Table 1). The 
records will also be in appropriate order for one-one linking in a spreadsheet 
(i.e., record five in the first segment belongs with record 5 in additional 
segments). 


Table Descriptions:

Brief descriptions of the individual tables can be found in Table 1. For a full 
description of each dataset please see the EIMS metadata records describing the 
data sets and the questionnaires.


Table 1. Data Tables in CTEPP NC, Their Descriptions, Ids, Number of Segments, 
         and Primary Keys                                                    

Primary Key Description                                          Key
--------------------------------------------------------------   --------------------                                    
Numeric identifier unique to each row of the analytical and      No (primary key)                                        
QA/QC results. Can be used to relate these tables or segments           
within these tables.            

Sample identifier, unique for each analytical sample. A sample   SID (not primary key)
may be analyzed for many compounds so this field is not a               
primary key. It will be the key typically used to link samples          
to daycares, classrooms, individuals, or households.            

Daycare identifier, unique for each daycare and coded as 97      DID (primary key)
for those not attending daycares. Some daycares had two                 
separate classrooms. These can be distinguished using the               
index file. It is a unique primary key for those tables it              
is used in.             

Family identifier, unique for each family. This may represent    PID (primary key)
a parent and child, a parent, or a child, depending on the              
type of sample taken or the particular table it is used in.                                                                     
For the tables it is used as a key in, it is unique and a                                                                       
primary key.                                                                    


Five Digit ID                                           Number of                       
(Record ID)     Description                             Segments    Primary Key                     
-------------   ------------------------------------    ---------  -----------------                                                       

76263           Analytical sample results               1          No SID (foreign key)
76364           QA/QC results                           1          No SID (foreign key)
76365           Child care center weekly menus          1          DID                     
76366           Supplemental information on field                                                       
                and lab samples                         1          SID     
76367           Data form 1, recruitment information                                            
                from daycare center participants        1          PID                     
76368           Form 1_RDD recruitment information                                              
                on home participants                    1          PID     
76369           Form 2, Home and building                                               
                characteristics for home participants   1          PID                     
76370           Form 3, House and building                                              
                characteristics for day care centers    1          DID                     
76371           Form 4, parent pre-monitoring                                           
                questionnaire                           3          PID
76372           Form 5, Child daycare center                                            
                pre-monitoring questionnaire            4          DID             
76373           Form 6,  Parent post-monitoring                                                 
                questionnaire                           3          PID
76374           Form 7, Child daycare center                                            
                post-monitoring questionnaire           1          PID             
76375           Form 8, Food survey data                8          PID
76376           Form 9, Food survey data                7          PID
76377           Frm10, Individual's food survey                                 
                data from child care center             3          PID
------------------------------------------------------------------------------------------                                              



Extracting Data From Multiple Tables:

Since data on analytical results, individuals, and daycares are spread across 
tables, linking the tables will be necessary to extract useful information. The 
relationships are most easily built using the supplied index file. This file 
relates data from the different tables and provides a few descriptive variables to 
make data extraction easier. 

The index table is shown linking to all of the tables via three relationships using 
the table keys SID, PID, and DID.  The variables in the index that relate to these 
keys are:
	Daycare: DID
	ID: PID
	SID: SID
Additional information in the index can assist in correct extraction desired of 
data:
	Scope: 	Indicates whom the sample is associated with: adult, child, both.
	Classroom:  Indicates classroom within a daycare: 
	0:          Daycare does not have separate classrooms, or child 
                        does not go to daycare.
	1:          Classroom 1 of 2 in daycare.
	2:          Classroom 2 of 2 in daycare.
	Location:   Whether sample was taken at subjects home or at daycare.	
	Sample:     Where or what was sampled: person, food, inside, outside.

	
Example Queries Returning Sample IDs:

To familiarize one with use of the index table several, samples are given here that 
return specific records from the index table. Once retrieved, these records can 
pull samples from the data tables. The samples are given in SAS format using 
PROC SQL.  The SQL should work fairly universally, but other aspects of the 
examples may need to be changed for specific systems. In SAS comments are preceded 
by an '*', this is where explanation of each  query is given.

  proc sql noprint;

  * Get SIDS related to a specific daycare;

	create table sidDaycare as
		select * from index 
			where daycare='12';

  * Get SIDS for daycare and specific classroom;

	create table sidClass as
		select * from index 
			where daycare='12' and class='1'
				order by subject;

  * Get SIDS for specific household;

	create table sidSub113 as
		select * from index
			where subject='113';

  * Get SIDS for specific household, separate adult and child samples;

	create table sidSub113Sort as
		select * from index
			where subject='113'
			order by age desc;

  * Get SIDS for any daycare related food samples;

	create table sidFood as
		select * from index
			where daycare='12' and location='daycare' 
			and sampled='food';

  * Get SIDS for drinking water related samples taken at daycare 12;
  * Note that you need to know the definitions of the matrix elements;
  * Also note that the query returns 6 records, but only 1 sample;
  *  was taken as you can see from the single SID in all records;

	create table sidDrink as
		select * from index
			where daycare='12' and location='daycare' 
			and substr(sid,1,3)='DRW';

	quit;

	
Example Queries Linking Tables:

The previous samples simply showed how to retrieve the linkage information from 
the index table. These samples take the additional step of linking information 
from the index with one or more data tables.

  proc sql noprint;

  * Retrieve data from questionnaire one for people in daycare 11;
  * It is assumed that a table created from 76367ds.txt was put;
  *   into a table named frm1ds;

	create table quest1 as
		select distinct i.id,q.*
			from index i, frm1ds q
			where i.id=q.pid and i.daycare='11';




   * Retrieve data from multiple questionnaires for people in;
   *   daycare twelve. This assumes 76367ds.txt and 76369ds.txt;
   *   were imported to tables frm1ds and frm2ds, respectively.

	create table quest12 as
		select distinct i.id,q.*,s.*
			from index i, frm1ds q, frm2ds s
			where     i.daycare='12'
				  and i.id=q.pid 
				  and i.id=s.pid;

  * Retrieve data from household-specific and daycare-specific;
  *    questionnaires for people in daycare 12;
  * Note that the daycare information is the same for all people;
  *   only one record is retrieved from the daycare table;
  *   and thus all values in a column derived from the daycare;
  *   table are the same; It is assumed that data from frm5ds1;
  *   were imported from 76372ds1.txt;

	create table quest15 as
		select distinct i.id,q.*,d.*
			from index i, frm1ds q, frm5ds1 d
			where     i.daycare='12'
				  and i.id=q.pid
				  and i.daycare=d.did;
	quit;

	

