
Data Set Metadata



Entry ID:

22844



Complete Data Set contains 227 columns, 11 rows, and 1 segment(s).



Name:

U.S.-MEXICO BORDER PROGRAM ARIZONA BORDER STUDY--QA ANALYTICAL RESULTS FOR PAHS
IN SPIKE SAMPLES


Abstract:

The PAHs in Spikes data set contains the analytical results for measurements of
up to 26 polynuclear aromatic hydrocarbons (PAHs) in 11 control samples (spikes)
of indoor air and food over 8 households of PAHs concentrations in spike
samples.  Measurements were made in spiked samples of indoor air and food.  The
samples were analyzed as part of the QA/QC protocols of the Border study.  The
PAHs of interest include Anthracene (CAS # 120-12-7), Benzo(ghi)pyrelene (CAS#
191-24-2), Chrysene (CAS#218-01-9), and Benzo[a]pyrene (CAS# 50-32-8).
Keywords: quality assurance; spikes; PAHs.
 
The U.S.-Mexico Border Program is sponsored by the Environmental Health
Workgroup of the Border 2012 Program.  The Environmental Health Workgroup?s
mission is ?to identify and address, in a binational framework, environmental
factors that pose the highest risk to human health so that exposure to such
factors may be reduced.?  To accomplish this mission, studies are performed to
help understand the interrelationships between environmental conditions and
human health.  The Arizona Border Study, sponsored by the Environmental Health
Workgroup, is an extension of the Arizona National Human Exposure Assessment
Survey (NHEXAS) Phase I Study.  The Arizona Border Study collected household
environmental and personal samples for chemical analysis, and questionnaires
were administered.  The NHEXAS Phase I Questionnaires were used with some
adjustments and were organized into seven modules (Descriptive, Baseline,
Technician, Follow-up, Time and activity diary, Dietary diary, and Supplement)
for simplicity in administration.  The questionnaires are designed for
collecting information that can be temporally related to the exposure,
concentration, and/or biological measurements.  The Arizona Border study sampled
residences determined by a population-based probability research design for
populations in the Arizona counties bordering Mexico, and measured metals,
pesticides, polynuclear aromatic hydrocarbons (PAHs), and volatile organic
compounds (VOCs).  Analytical results were obtained under strict QA/QC
requirements during collection, processing, and final deposition into databases.
In addition, strict standard operating procedures were followed throughout the
Arizona Border study.  The study was conducted by a consortium composed of the
University of Arizona, Battelle Columbus, and the Illinois Institute of
Technology.  Data collection occurred between September 1997 and July 1998 for
the participating households.


Data Use and Constraints:

HEDS is a rich source of data that EPA encourages you to use for research and
analysis. Users must be familiar with data file manipulation and analysis.  EPA
cannot analyze, check results, debug programs, or review literature for your
work. Thoroughly reviewing the documentation on the survey's planning, analytic
guidelines, and datasets available through HEDS and EIMS should resolve most
questions. If you have questions after reviewing the documentation, please
contact the Human Exposure and Atmospheric Sciences Division at 919-541-3184 or
email "admin.heds@epa.gov". Please review the data use restrictions in the
Notice field and your agreement to comply with these restrictions in using the
data.
 
These data are the result of a probability-based sampling design specific to
the population under study. Thus the data may or may not be representative of
subsets of this study's population or of other populations. The study was
designed to test certain hypotheses, which may limit its applicability for other
purposes. When using these data it is important to consider the percentage of
non-responses or non-detects in the data as an indicator of its usefulness for
other purposes. The U.S. EPA accepts no liability for any errors or omissions in
the results included in the data sets, associated information, and/or
documentation.
 
Based on the output format selected by the user and the software into which
the data set is imported, users may notice measurements and sampling weights are
zero-padded to the right of non-zero decimal digits. These zeroes are a function
of the formatting process and the software's acceptance of that format and
should not be construed as significant digits in the value. Measurement values
are provided with four significant digits; sampling weights are provided with
three decimal digits.
 
Some code values may have been revised from the values on the original
questionnaire forms.  Check the appropriate code set supplied with the data.


Notice:

WARNING! DATA USE RESTRICTIONS
 
Read Carefully Before Using
 
The EPA does all it can to ensure that the
identity of survey participants cannot be disclosed.  All direct identifiers, as
well as any characteristics that might lead to identifications, are omitted from
the data.  Any intentional identification or disclosure of a person or
establishment violates the assurances of confidentiality given to the providers
of the information.  Therefore, users will (1) use the data in this study for
statistical reporting and analysis only; (2) make no use of the identity of any
person or establishment discovered inadvertently and will advise the HEDS
Administrator of any such discovery; (3) will not link this data with
individually identifiable data from other EPA or non-EPA data.
 
By using the data you signify your agreement to comply with the above-stated
statutorily based requirements.


Additional Information:

To access the data set, select the Downloads link on the navigation bar to the
left.  Then select the download entry "Download Data Set."
 
Please review the "Data Use & Constraints" information by selecting the
Quality Assurance link to the left.


Version:

1.0


Version Description:

(Not currently available.)





For more information on the structure of the files included in this package,
please see the document "HEDS How To Use--Reference", accessible from the
HEDS Home Page.

